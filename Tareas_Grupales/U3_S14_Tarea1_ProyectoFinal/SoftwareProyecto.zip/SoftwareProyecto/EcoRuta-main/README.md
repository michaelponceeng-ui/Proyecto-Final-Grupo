# EcoRuta

Sistema web para gestionar incidencias de residuos, rutas de recolección y seguimiento operativo en zonas urbanas de Guayaquil.

## Tecnologías

- Frontend: Angular 21
- Backend: PHP 8 con API REST y PDO
- Base de datos: MySQL 8

## Instalación

1. Importar `database/01-create-database.sql` y `database/02-insert-datos-base.sql`.
2. Configurar variables de entorno de MySQL o editar `backend/config.php`.
3. Ejecutar el API: `php -S localhost:8080 -t backend`.
4. Instalar y ejecutar el frontend:
   - `cd ecoruta-frontend`
   - `npm install`
   - `npm start`

## Credenciales demo

- Administrador: `admin@ecoruta.gob.ec` / `admin123`
- Operador: `operador@ecoruta.gob.ec` / `oper123`
