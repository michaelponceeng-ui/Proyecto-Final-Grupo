<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: http://localhost:4200');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$config = require __DIR__ . '/config.php';
$dsn = sprintf(
    'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
    $config['host'],
    $config['port'],
    $config['database']
);

function respond(int $status, array $payload): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $exception) {
    respond(500, ['error' => 'No se pudo conectar a MySQL']);
}

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$resource = basename($path);
$body = json_decode((string) file_get_contents('php://input'), true) ?: [];

if ($resource === 'login' && $method === 'POST') {
    $email = trim((string) ($body['email'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $demoUsers = [
        'admin@ecoruta.gob.ec' => [
            'password' => 'admin123',
            'usuario' => ['id' => 1, 'nombre' => 'Administrador EcoRuta', 'email' => 'admin@ecoruta.gob.ec', 'rol' => 'ADMIN', 'activo' => 1, 'base_id' => null],
        ],
        'operador@ecoruta.gob.ec' => [
            'password' => 'oper123',
            'usuario' => ['id' => 2, 'nombre' => 'Carlos Mendoza', 'email' => 'operador@ecoruta.gob.ec', 'rol' => 'OPERADOR', 'activo' => 1, 'base_id' => 1],
        ],
    ];
    if (isset($demoUsers[$email]) && hash_equals($demoUsers[$email]['password'], $password)) {
        respond(200, ['usuario' => $demoUsers[$email]['usuario'], 'token' => bin2hex(random_bytes(24))]);
    }
    $stmt = $pdo->prepare('SELECT id, nombre, email, password_hash, rol, activo, base_id FROM usuarios WHERE email = :email AND activo = 1');
    $stmt->execute(['email' => $email]);
    $usuario = $stmt->fetch();
    if (!$usuario || !password_verify($password, (string) ($usuario['password_hash'] ?? ''))) {
        respond(401, ['error' => 'Credenciales incorrectas']);
    }
    unset($usuario['password_hash']);
    respond(200, ['usuario' => $usuario, 'token' => bin2hex(random_bytes(24))]);
}

if ($resource === 'incidents' && $method === 'GET') {
    $stmt = $pdo->query(
        'SELECT i.*, s.nombre AS sector_nombre
         FROM incidencias i
         JOIN sectores s ON s.id = i.sector_id
         ORDER BY i.fecha_creacion DESC'
    );
    respond(200, $stmt->fetchAll());
}

if ($resource === 'incidents' && $method === 'POST') {
    $sql = 'INSERT INTO incidencias
            (sector_id, tipo, estado, prioridad, direccion, volumen_estimado, descripcion)
            VALUES (:sector_id, :tipo, :estado, :prioridad, :direccion, :volumen, :descripcion)';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'sector_id' => (int) ($body['sector_id'] ?? 1),
        'tipo' => $body['tipo'] ?? 'ORGANICO',
        'estado' => 'PENDIENTE',
        'prioridad' => $body['prioridad'] ?? 'MEDIA',
        'direccion' => trim((string) ($body['direccion'] ?? '')),
        'volumen' => (float) ($body['volumen_estimado'] ?? 0),
        'descripcion' => trim((string) ($body['descripcion'] ?? '')),
    ]);
    respond(201, ['id' => (int) $pdo->lastInsertId()]);
}

if ($resource === 'stats' && $method === 'GET') {
    $stmt = $pdo->query(
        'SELECT
            SUM(estado = "PENDIENTE") AS pendientes,
            SUM(estado = "EN_RUTA") AS en_ruta,
            SUM(estado = "COMPLETADA") AS completadas,
            ROUND(COALESCE(SUM(volumen_estimado), 0), 2) AS volumen
         FROM incidencias'
    );
    respond(200, $stmt->fetch());
}

respond(404, ['error' => 'Recurso no encontrado']);
