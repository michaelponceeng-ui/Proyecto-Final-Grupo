USE ecoruta;

INSERT INTO centros_operativos (nombre,direccion,lat,lng) VALUES
('Centro Norte','Av. Benjamín Rosales y Av. de las Américas',-2.171,-79.897),
('Terminal Sur','Av. 25 de Julio y Pascuales',-2.234,-79.902),
('Base Daule','Vía a Daule Km 8',-2.112,-79.925);

INSERT INTO sectores (nombre,zona,lat,lng) VALUES
('Centro','Centro',-2.190,-79.880),
('Urdesa','Norte',-2.177,-79.904),
('Samborondón','Norte',-2.142,-79.845),
('Sauces','Residencial',-2.137,-79.917),
('Daule','Periferia',-2.098,-79.930),
('Sur','Sur',-2.221,-79.903);

INSERT INTO usuarios (nombre,email,password_hash,rol,activo,base_id) VALUES
('Administrador EcoRuta','admin@ecoruta.gob.ec','$2y$10$demo', 'ADMIN',1,NULL),
('Carlos Mendoza','operador@ecoruta.gob.ec','$2y$10$demo', 'OPERADOR',1,1);

INSERT INTO incidencias (sector_id,tipo,estado,prioridad,direccion,volumen_estimado,descripcion) VALUES
(1,'ORGANICO','PENDIENTE','ALTA','Av. 9 de Octubre y Boyacá',2.40,'Acumulación de residuos orgánicos'),
(2,'RECICLABLE','EN_RUTA','MEDIA','Vía Urdesa Central',1.20,'Contenedores reciclables completos'),
(3,'PELIGROSO','PENDIENTE','ALTA','Cdla. Nueva Kennedy',0.80,'Material especial sin señalizar'),
(4,'ORGANICO','COMPLETADA','BAJA','Av. Las Monjas',3.10,'Recolección domiciliaria'),
(5,'RECICLABLE','EN_RUTA','MEDIA','Vía a Daule km 8',1.70,'Punto de reciclaje saturado'),
(6,'ORGANICO','PENDIENTE','ALTA','Cooperativa 28 de Agosto',2.20,'Desborde de contenedor');
