import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as L from 'leaflet';
import { AuthService } from '../../services/auth.service';
import type { Usuario } from '../../models/usuario.model';

interface Incidencia {
  id: number;
  sector: string;
  tipo: 'ORGÁNICO' | 'RECICLABLE' | 'PELIGROSO';
  estado: 'PENDIENTE' | 'EN_RUTA' | 'COMPLETADA';
  prioridad: 'ALTA' | 'MEDIA' | 'BAJA';
  direccion: string;
  volumen: number;
  latitud: number;
  longitud: number;
  asignadoA: number | null;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <main class="shell">
      <header class="topbar">
        <div class="brand"><span>&#9851;</span><strong>EcoRuta</strong></div>
        <div class="actions">
          <span class="zone">{{ auth.esAdmin() ? 'ADMINISTRADOR' : 'TRABAJADOR' }} · GUAYAQUIL</span>
          @if (auth.esAdmin()) {
            <button (click)="nuevaIncidencia = !nuevaIncidencia">+ Nueva incidencia</button>
          }
          <button class="logout" (click)="auth.logout()">Cerrar sesión</button>
        </div>
      </header>

      @if (auth.esAdmin()) {
        <section class="stats">
          <article><span>Puntos pendientes</span><strong>{{ pendientes() }}</strong><small>en toda la operación</small></article>
          <article><span>En recolección</span><strong>{{ enRuta() }}</strong><small>rutas activas</small></article>
          <article><span>Completadas</span><strong>{{ completadas() }}</strong><small>servicios finalizados</small></article>
          <article><span>Volumen estimado</span><strong>{{ volumen() }} t</strong><small>toneladas de residuos</small></article>
        </section>
      } @else {
        <section class="stats">
          <article><span>Mis tareas</span><strong>{{ incidenciasVisibles().length }}</strong><small>asignadas a mi cuenta</small></article>
          <article><span>Por iniciar</span><strong>{{ pendientesPersonales() }}</strong><small>listas para recoger</small></article>
          <article><span>En recolección</span><strong>{{ enRutaPersonal() }}</strong><small>tareas en curso</small></article>
          <article><span>Completadas</span><strong>{{ completadasPersonales() }}</strong><small>tareas finalizadas</small></article>
        </section>
      }

      @if (auth.esAdmin() && nuevaIncidencia) {
        <section class="form-card">
          <input [(ngModel)]="sector" placeholder="Sector">
          <input [(ngModel)]="direccion" placeholder="Dirección">
          <select [(ngModel)]="tipo">
            <option>ORGÁNICO</option><option>RECICLABLE</option><option>PELIGROSO</option>
          </select>
          <select [(ngModel)]="tecnicoAsignado" aria-label="Asignar a operador">
            <option value="">Sin asignar</option>
            @for (tecnico of tecnicos; track tecnico.id) {
              <option [value]="tecnico.id">{{ tecnico.nombre }}</option>
            }
          </select>
          <button (click)="agregar()">Guardar incidencia</button>
        </section>
      }

      <section class="workspace">
        <div class="map-panel">
          <div class="map-head"><div><small>GUAYAS · ECUADOR</small><h2>Zonas de recolección</h2></div><div class="legend"><i></i> Pendiente <i></i> En ruta <i></i> Completa</div></div>
          <div #mapa class="map" role="application" aria-label="Mapa interactivo de incidencias en Guayas"></div>
        </div>

        <aside class="table-panel">
          <h2>{{ auth.esAdmin() ? 'Todas las incidencias' : 'Mis tareas asignadas' }}</h2>
          @if (incidenciasVisibles().length === 0) {
            <p class="empty-state">No tienes tareas asignadas por ahora.</p>
          }
          @for (punto of incidenciasVisibles(); track punto.id) {
            <article class="row" [class.selected]="seleccion()?.id === punto.id" (click)="seleccionar(punto)">
              <div class="tag {{ punto.tipo.toLowerCase() }}">{{ punto.tipo }}</div>
              <div><strong>{{ punto.sector }}</strong><small>{{ punto.direccion }}</small></div>
              @if (auth.esAdmin()) {
                <div class="row-controls">
                  <span class="status {{ punto.estado.toLowerCase().replace('_','-') }}">{{ punto.estado }}</span>
                  <label class="assignment-label">
                    Responsable
                    <select [ngModel]="punto.asignadoA" (ngModelChange)="asignar(punto.id, $event)" [ngModelOptions]="{standalone: true}" [attr.aria-label]="'Asignar ' + punto.sector">
                      <option [ngValue]="null">Sin asignar</option>
                      @for (tecnico of tecnicos; track tecnico.id) {
                        <option [ngValue]="tecnico.id">{{ tecnico.nombre }}</option>
                      }
                    </select>
                  </label>
                </div>
              } @else {
                <div class="row-controls">
                  <span class="status {{ punto.estado.toLowerCase().replace('_','-') }}">{{ punto.estado }}</span>
                  <button class="task-action" [disabled]="punto.estado === 'COMPLETADA'" (click)="avanzar(punto); $event.stopPropagation()">
                    {{ punto.estado === 'PENDIENTE' ? 'Iniciar recolección' : punto.estado === 'EN_RUTA' ? 'Completar tarea' : 'Completada' }}
                  </button>
                </div>
              }
            </article>
          }
        </aside>
      </section>
    </main>
  `,
  styles: [`
    :host { display:block; height:100vh; }
    .shell { height:100vh; background:#eef3ef; color:#1c2d28; overflow:auto; font-family:Inter,sans-serif; }
    .topbar { height:68px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; background:#17352b; color:white; }
    .brand { display:flex; align-items:center; gap:10px; font-size:20px; } .brand span { color:#86d8ad; font-size:28px; }
    .actions { display:flex; align-items:center; gap:16px; } .zone { font-size:11px; letter-spacing:1.5px; color:#b9ccc4; }
    button { border:0; cursor:pointer; } .actions button,.form-card button { background:#5fc08a; color:#10271e; border-radius:8px; padding:10px 14px; font-weight:700; }
    .actions .logout { background:transparent; color:#f0b4a9; border:1px solid rgba(240,180,169,.55); }
    .actions .logout:hover { background:rgba(240,180,169,.12); }
    .stats { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; padding:18px 28px 10px; }
    .stats article { background:white; border-radius:12px; padding:16px 18px; display:flex; flex-direction:column; box-shadow:0 4px 18px rgba(28,45,40,.06); border-left:4px solid #76c69b; }
    .stats span { color:#6a7d75; font-size:12px; } .stats strong { font-size:28px; margin:4px 0; } .stats small { color:#94a39d; }
    .form-card { margin:8px 28px; background:white; border-radius:12px; padding:12px; display:flex; gap:10px; }
    .form-card input,.form-card select { flex:1; min-width:0; border:1px solid #d8e3dd; border-radius:8px; padding:10px; background:white; }
    .workspace { height:calc(100vh - 230px); min-height:430px; display:grid; grid-template-columns:minmax(0,1.7fr) minmax(300px,.7fr); gap:14px; padding:10px 28px 24px; }
    .map-panel,.table-panel { background:white; border-radius:14px; overflow:hidden; box-shadow:0 4px 18px rgba(28,45,40,.06); }
    .map-head { height:76px; display:flex; justify-content:space-between; align-items:center; padding:14px 18px; } .map-head small { color:#7e948a; letter-spacing:1.2px; } .map-head h2,.table-panel h2 { margin-top:4px; }
    .legend { font-size:11px; color:#718279; } .legend i { width:8px; height:8px; border-radius:50%; display:inline-block; margin-left:8px; margin-right:3px; background:#eab34b; }
    .legend i:nth-child(2){background:#3b82af}.legend i:nth-child(3){background:#50a875}
    .map { height:calc(100% - 76px); min-height:300px; background:#e5eee8; }
    .table-panel { padding:18px; overflow:auto; } .table-panel h2 { margin-bottom:12px; } .row { display:grid; grid-template-columns:76px minmax(0,1fr) 132px; align-items:center; gap:8px; padding:12px 8px; border-bottom:1px solid #edf1ef; cursor:pointer; }.row.selected{background:#f3f8f5;border-radius:8px}
    .row strong,.row small { display:block; }.row small { color:#829189;margin-top:3px; } .tag { font-size:9px; font-weight:800; padding:5px 7px; border-radius:12px;text-align:center }.tag.orgánico{background:#dcefe3;color:#2d7751}.tag.reciclable{background:#d7e8f4;color:#2f6f95}.tag.peligroso{background:#f7dfdc;color:#9a493f}
    .status { font-size:9px;text-align:center;padding:5px;border-radius:8px;background:#f5ecd2;color:#87691d}.status.en-ruta{background:#dceaf3;color:#39718f}.status.completada{background:#dceee3;color:#397151}
    .row-controls { display:flex; flex-direction:column; align-items:stretch; gap:6px; }
    .assignment-label { color:#829189; font-size:10px; }
    .assignment-label select { width:100%; margin-top:3px; padding:5px; border:1px solid #d8e3dd; border-radius:6px; background:white; color:#1c2d28; font-size:10px; }
    .task-action { padding:6px 7px; border:1px solid #b8ddc8; border-radius:6px; background:#e9f5ed; color:#286b47; font-size:10px; font-weight:700; }
    .task-action:disabled { border-color:#dbe5df; background:#f2f5f3; color:#84928a; cursor:default; }
    .empty-state { padding:16px 8px; color:#829189; font-size:13px; }
    @media(max-width:900px){.stats{grid-template-columns:repeat(2,1fr)}.workspace{height:auto;grid-template-columns:1fr}.map-panel{height:460px}.table-panel{max-height:440px}.zone{display:none}}
  `]
})
export class DashboardComponent implements AfterViewInit, OnDestroy {
  readonly tecnicos: Usuario[];

  constructor(public auth: AuthService) {
    this.tecnicos = auth.obtenerTecnicos();
  }

  @ViewChild('mapa') private mapaElement!: ElementRef<HTMLDivElement>;
  private mapa: L.Map | null = null;
  private marcadores = new Map<number, L.CircleMarker>();
  private readonly storageKey = 'ecoruta_incidencias';
  private readonly incidenciasIniciales: Incidencia[] = [
    { id:1, sector:'Centro', tipo:'ORGÁNICO', estado:'PENDIENTE', prioridad:'ALTA', direccion:'Av. 9 de Octubre y Boyacá', volumen:2.4, latitud:-2.1962, longitud:-79.8862, asignadoA:2 },
    { id:2, sector:'Urdesa', tipo:'RECICLABLE', estado:'EN_RUTA', prioridad:'MEDIA', direccion:'Vía Urdesa Central', volumen:1.2, latitud:-2.1710, longitud:-79.9070, asignadoA:2 },
    { id:3, sector:'Samborondón', tipo:'PELIGROSO', estado:'PENDIENTE', prioridad:'ALTA', direccion:'Av. Samborondón, km 2', volumen:0.8, latitud:-2.1390, longitud:-79.8680, asignadoA:3 },
    { id:4, sector:'Sauces', tipo:'ORGÁNICO', estado:'COMPLETADA', prioridad:'BAJA', direccion:'Av. Isidro Ayora, sector Sauces', volumen:3.1, latitud:-2.1340, longitud:-79.9020, asignadoA:3 },
    { id:5, sector:'Norte', tipo:'RECICLABLE', estado:'EN_RUTA', prioridad:'MEDIA', direccion:'Vía a Daule km 8', volumen:1.7, latitud:-2.1050, longitud:-79.9280, asignadoA:2 },
    { id:6, sector:'Sur', tipo:'ORGÁNICO', estado:'PENDIENTE', prioridad:'ALTA', direccion:'Cooperativa 28 de Agosto', volumen:2.2, latitud:-2.2500, longitud:-79.9000, asignadoA:3 }
  ];
  nuevaIncidencia = false;
  sector = '';
  direccion = '';
  tipo: Incidencia['tipo'] = 'ORGÁNICO';
  tecnicoAsignado = '';
  seleccion = signal<Incidencia | null>(null);
  incidencias = signal<Incidencia[]>(this.cargarIncidencias());
  incidenciasVisibles = computed(() => {
    if (this.auth.esAdmin()) return this.incidencias();
    const usuarioId = this.auth.usuario()?.id;
    return this.incidencias().filter(punto => punto.asignadoA === usuarioId);
  });
  pendientes = () => this.incidencias().filter(i => i.estado === 'PENDIENTE').length;
  enRuta = () => this.incidencias().filter(i => i.estado === 'EN_RUTA').length;
  completadas = () => this.incidencias().filter(i => i.estado === 'COMPLETADA').length;
  volumen = () => this.incidencias().reduce((sum, i) => sum + i.volumen, 0).toFixed(1);
  pendientesPersonales = computed(() => this.incidenciasVisibles().filter(i => i.estado === 'PENDIENTE').length);
  enRutaPersonal = computed(() => this.incidenciasVisibles().filter(i => i.estado === 'EN_RUTA').length);
  completadasPersonales = computed(() => this.incidenciasVisibles().filter(i => i.estado === 'COMPLETADA').length);

  ngAfterViewInit() {
    this.mapa = L.map(this.mapaElement.nativeElement, {
      center: [-2.17, -79.89],
      zoom: 11,
      scrollWheelZoom: true
    });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(this.mapa);
    this.actualizarMarcadores();
  }

  ngOnDestroy() {
    this.mapa?.remove();
  }

  seleccionar(punto: Incidencia) {
    this.seleccion.set(punto);
    if (this.mapa) {
      this.mapa.flyTo([punto.latitud, punto.longitud], Math.max(this.mapa.getZoom(), 14));
    }
    this.marcadores.get(punto.id)?.openPopup();
  }

  agregar() {
    if (!this.sector.trim() || !this.direccion.trim()) return;
    const ubicacion = this.coordenadasDelSector(this.sector);
    if (!this.auth.esAdmin()) return;
    const tecnicoId = this.tecnicoAsignado ? Number(this.tecnicoAsignado) : null;
    const nuevasIncidencias = [{
      id:Date.now(), sector:this.sector, direccion:this.direccion, tipo:this.tipo,
      estado:'PENDIENTE' as const, prioridad:'MEDIA' as const, volumen:1, ...ubicacion, asignadoA:tecnicoId
    }, ...this.incidencias()];
    this.incidencias.set(nuevasIncidencias);
    this.guardarIncidencias(nuevasIncidencias);
    this.actualizarMarcadores();
    this.sector=''; this.direccion=''; this.tecnicoAsignado=''; this.nuevaIncidencia=false;
  }

  asignar(id: number, tecnicoId: number | null) {
    if (!this.auth.esAdmin()) return;
    if (tecnicoId !== null && !this.tecnicos.some(tecnico => tecnico.id === tecnicoId)) {
      throw new Error('El operador seleccionado no es válido.');
    }

    const nuevasIncidencias = this.incidencias().map(punto =>
      punto.id === id ? { ...punto, asignadoA: tecnicoId } : punto
    );
    this.incidencias.set(nuevasIncidencias);
    this.guardarIncidencias(nuevasIncidencias);
    this.actualizarMarcadores();
  }

  avanzar(punto: Incidencia) {
    if (this.auth.esAdmin() || this.auth.usuario()?.id !== punto.asignadoA || punto.estado === 'COMPLETADA') return;
    const estado: Incidencia['estado'] = punto.estado === 'PENDIENTE' ? 'EN_RUTA' : 'COMPLETADA';
    const nuevasIncidencias = this.incidencias().map(incidencia =>
      incidencia.id === punto.id ? { ...incidencia, estado } : incidencia
    );
    this.incidencias.set(nuevasIncidencias);
    this.guardarIncidencias(nuevasIncidencias);
    const actualizada = nuevasIncidencias.find(incidencia => incidencia.id === punto.id);
    if (actualizada) this.seleccion.set(actualizada);
    this.actualizarMarcadores();
  }

  private cargarIncidencias(): Incidencia[] {
    const guardadas = localStorage.getItem(this.storageKey);
    if (guardadas === null) return this.incidenciasIniciales;

    const datos: unknown = JSON.parse(guardadas);
    if (!Array.isArray(datos) || !datos.every(punto => this.esIncidencia(punto))) {
      throw new Error('Las incidencias guardadas localmente tienen un formato inválido.');
    }
    return datos;
  }

  private esIncidencia(valor: unknown): valor is Incidencia {
    if (typeof valor !== 'object' || valor === null) return false;
    const incidencia = valor as Record<string, unknown>;
    return typeof incidencia['id'] === 'number'
      && typeof incidencia['sector'] === 'string'
      && typeof incidencia['tipo'] === 'string'
      && typeof incidencia['estado'] === 'string'
      && typeof incidencia['prioridad'] === 'string'
      && typeof incidencia['direccion'] === 'string'
      && typeof incidencia['volumen'] === 'number'
      && typeof incidencia['latitud'] === 'number'
      && typeof incidencia['longitud'] === 'number'
      && (incidencia['asignadoA'] === null || typeof incidencia['asignadoA'] === 'number');
  }

  private guardarIncidencias(incidencias: Incidencia[]) {
    localStorage.setItem(this.storageKey, JSON.stringify(incidencias));
  }

  private actualizarMarcadores() {
    if (!this.mapa) return;

    this.marcadores.forEach(marcador => marcador.remove());
    this.marcadores.clear();
    const puntos = this.incidenciasVisibles();

    for (const punto of puntos) {
      const color = punto.estado === 'PENDIENTE' ? '#eab34b'
        : punto.estado === 'EN_RUTA' ? '#3b82af' : '#50a875';
      const marcador = L.circleMarker([punto.latitud, punto.longitud], {
        radius: 9,
        color: '#ffffff',
        weight: 2,
        fillColor: color,
        fillOpacity: 1
      }).addTo(this.mapa);
      marcador.bindPopup(this.crearPopup(punto));
      marcador.on('click', () => this.seleccion.set(punto));
      this.marcadores.set(punto.id, marcador);
    }

    if (puntos.length) {
      this.mapa.fitBounds(L.latLngBounds(puntos.map(punto => L.latLng(punto.latitud, punto.longitud))), { padding: [24, 24], maxZoom: 12 });
    }
  }

  private crearPopup(punto: Incidencia): HTMLElement {
    const popup = document.createElement('div');
    const titulo = document.createElement('strong');
    titulo.textContent = punto.sector;
    const direccion = document.createElement('div');
    direccion.textContent = punto.direccion;
    const estado = document.createElement('div');
    estado.textContent = punto.estado.replace('_', ' ');
    popup.append(titulo, direccion, estado);
    return popup;
  }

  private coordenadasDelSector(sector: string): { latitud: number; longitud: number } {
    const nombre = sector.trim().toLocaleLowerCase();
    const ubicaciones: Record<string, [number, number]> = {
      centro: [-2.1962, -79.8862],
      urdesa: [-2.1710, -79.9070],
      samborondón: [-2.1390, -79.8680],
      samborondon: [-2.1390, -79.8680],
      sauces: [-2.1340, -79.9020],
      norte: [-2.1050, -79.9280],
      sur: [-2.2500, -79.9000]
    };
    const [latitud, longitud] = ubicaciones[nombre] ?? [-2.17, -79.89];
    return { latitud, longitud };
  }
}
