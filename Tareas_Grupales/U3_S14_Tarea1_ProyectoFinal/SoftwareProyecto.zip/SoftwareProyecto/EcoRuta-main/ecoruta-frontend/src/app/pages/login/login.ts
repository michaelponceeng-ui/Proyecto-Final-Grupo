import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-page">
      <div class="login-bg">
        <div class="grid-overlay"></div>
      </div>

      <div class="login-card">
        <div class="login-header">
          <div class="logo-circle"><span>&#9851;</span></div>
          <h1>EcoRuta</h1>
          <p>Gestión Inteligente de Residuos Urbanos</p>
          <span class="city-tag">Guayaquil</span>
        </div>

        <form (ngSubmit)="iniciarSesion()" class="login-form">
          <div class="form-group">
            <label for="email">Correo electr&oacute;nico</label>
            <input
              id="email"
              type="email"
              [(ngModel)]="email"
              name="email"
              placeholder="usuario@ecoruta.gob.ec"
              required
              autocomplete="email"
            />
          </div>

          <div class="form-group">
            <label for="password">Contrase&ntilde;a</label>
            <input
              id="password"
              type="password"
              [(ngModel)]="password"
              name="password"
              placeholder="Ingrese su contrase&ntilde;a"
              required
              autocomplete="current-password"
            />
          </div>

          @if (error()) {
            <div class="error-msg">{{ error() }}</div>
          }

          <button type="submit" class="btn-login" [disabled]="cargando()">
            {{ cargando() ? 'Ingresando...' : 'Ingresar' }}
          </button>
        </form>

        <div class="demo-info">
          <p class="demo-title">Credenciales Demo</p>
          <div class="demo-creds">
            <div class="demo-item" (click)="usarCredencial('admin@ecoruta.gob.ec', 'admin123')">
              <strong>Admin:</strong> admin&#64;ecoruta.gob.ec / admin123
            </div>
            <div class="demo-item" (click)="usarCredencial('operador@ecoruta.gob.ec', 'oper123')">
              <strong>Operador:</strong> operador&#64;ecoruta.gob.ec / oper123
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-page {
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #0f172a;
      position: relative;
      overflow: hidden;
    }

    .login-bg {
      position: absolute;
      inset: 0;
      background: radial-gradient(ellipse at 30% 50%, rgba(251, 191, 36, 0.08) 0%, transparent 60%),
                  radial-gradient(ellipse at 70% 50%, rgba(59, 130, 246, 0.08) 0%, transparent 60%);
    }

    .grid-overlay {
      position: absolute;
      inset: 0;
      background-image:
        linear-gradient(rgba(148, 163, 184, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(148, 163, 184, 0.03) 1px, transparent 1px);
      background-size: 60px 60px;
    }

    .login-card {
      position: relative;
      background: rgba(30, 41, 59, 0.8);
      backdrop-filter: blur(20px);
      border: 1px solid #334155;
      border-radius: 16px;
      padding: 40px;
      width: 400px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    }

    .login-header {
      text-align: center;
      margin-bottom: 32px;
    }

    .logo-circle {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px;
      font-size: 28px;
    }

    h1 {
      color: #fbbf24;
      font-size: 32px;
      font-weight: 800;
      letter-spacing: 6px;
      margin: 0;
    }

    .login-header p {
      color: #94a3b8;
      font-size: 13px;
      margin: 8px 0;
    }

    .city-tag {
      display: inline-block;
      background: rgba(59, 130, 246, 0.15);
      color: #60a5fa;
      padding: 4px 16px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      border: 1px solid rgba(59, 130, 246, 0.3);
      letter-spacing: 1px;
      text-transform: uppercase;
    }

    .login-form {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .form-group label {
      color: #94a3b8;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .form-group input {
      background: #0f172a;
      border: 1px solid #334155;
      border-radius: 8px;
      padding: 12px 16px;
      color: #e2e8f0;
      font-size: 14px;
      transition: border-color 0.2s;
    }

    .form-group input:focus {
      outline: none;
      border-color: #fbbf24;
      box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.1);
    }

    .form-group input::placeholder {
      color: #475569;
    }

    .error-msg {
      background: rgba(239, 68, 68, 0.15);
      color: #f87171;
      padding: 10px 16px;
      border-radius: 8px;
      font-size: 13px;
      border: 1px solid rgba(239, 68, 68, 0.3);
      text-align: center;
    }

    .btn-login {
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #0f172a;
      border: none;
      border-radius: 8px;
      padding: 14px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 8px;
    }

    .btn-login:hover {
      transform: translateY(-1px);
      box-shadow: 0 4px 20px rgba(251, 191, 36, 0.3);
    }

    .btn-login:disabled {
      opacity: 0.7;
      cursor: not-allowed;
      transform: none;
    }

    .demo-info {
      margin-top: 24px;
      padding-top: 20px;
      border-top: 1px solid #334155;
    }

    .demo-title {
      color: #64748b;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin: 0 0 10px 0;
      text-align: center;
    }

    .demo-creds {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .demo-item {
      background: #0f172a;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 11px;
      color: #94a3b8;
      cursor: pointer;
      transition: all 0.2s;
      border: 1px solid transparent;
    }

    .demo-item:hover {
      border-color: #fbbf24;
      color: #e2e8f0;
    }

    .demo-item strong {
      color: #fbbf24;
    }
  `]
})
export class LoginComponent {
  email = '';
  password = '';
  error = signal('');
  cargando = signal(false);

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    if (this.authService.estaAutenticado()) {
      this.router.navigate(['/dashboard']);
    }
  }

  usarCredencial(email: string, password: string): void {
    this.email = email;
    this.password = password;
  }

  iniciarSesion(): void {
    this.error.set('');
    this.cargando.set(true);

    setTimeout(() => {
      const resultado = this.authService.login({
        email: this.email,
        password: this.password
      });

      if (resultado.exito) {
        this.router.navigate(['/dashboard']);
      } else {
        this.error.set(resultado.mensaje);
      }
      this.cargando.set(false);
    }, 500);
  }
}
