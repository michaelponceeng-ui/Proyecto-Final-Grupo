export interface CentroOperativo {
  id: number;
  nombre: string;
  direccion: string;
  lat: number;
  lng: number;
}

export interface Usuario {
  id: number;
  nombre: string;
  email: string;
  rol: RolUsuario;
  activo: boolean;
  baseId?: number;
}

export enum RolUsuario {
  ADMIN = 'ADMIN',
  TECNICO = 'TECNICO'
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  usuario: Usuario;
  token: string;
}
