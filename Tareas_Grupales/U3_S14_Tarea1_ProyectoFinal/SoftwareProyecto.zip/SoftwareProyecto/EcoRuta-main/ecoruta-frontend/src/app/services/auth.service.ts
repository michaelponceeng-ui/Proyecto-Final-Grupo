import { Injectable, signal, computed } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario, RolUsuario, CentroOperativo, LoginRequest } from '../models/usuario.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private usuarioActual = signal<Usuario | null>(null);

  readonly usuario = this.usuarioActual.asReadonly();
  readonly estaAutenticado = computed(() => this.usuarioActual() !== null);
  readonly esAdmin = computed(() => this.usuarioActual()?.rol === RolUsuario.ADMIN);

  // Centros operativos del sistema EcoRuta
  readonly centros: CentroOperativo[] = [
    {
      id: 1,
      nombre: 'Centro Norte',
      direccion: 'Av. Benjamín Rosales y Av. de las Américas',
      lat: -2.171,
      lng: -79.897
    },
    {
      id: 2,
      nombre: 'Terminal Sur',
      direccion: 'Av. 25 de Julio y Pascuales',
      lat: -2.234,
      lng: -79.902
    },
    {
      id: 3,
      nombre: 'Base Daule',
      direccion: 'Vía a Daule Km 8',
      lat: -2.112,
      lng: -79.925
    },
  ];

  // Usuarios demo
  private readonly usuariosDemo: (Usuario & { password: string })[] = [
    { id: 1, nombre: 'Administrador EcoRuta', email: 'admin@ecoruta.gob.ec', rol: RolUsuario.ADMIN, activo: true, password: 'admin123' },
    { id: 2, nombre: 'Carlos Mendoza', email: 'operador@ecoruta.gob.ec', rol: RolUsuario.TECNICO, activo: true, password: 'oper123', baseId: 1 },
    { id: 3, nombre: 'María López', email: 'mlopez@ecoruta.gob.ec', rol: RolUsuario.TECNICO, activo: true, password: 'oper123', baseId: 2 }
  ];

  constructor(private router: Router) {
    const guardado = localStorage.getItem('ecoruta_usuario');
    if (guardado) {
      this.usuarioActual.set(JSON.parse(guardado));
    }
  }

  login(request: LoginRequest): { exito: boolean; mensaje: string } {
    const usuario = this.usuariosDemo.find(
      u => u.email === request.email && u.password === request.password
    );

    if (!usuario) {
      return { exito: false, mensaje: 'Credenciales incorrectas' };
    }

    const { password, ...datosUsuario } = usuario;
    this.usuarioActual.set(datosUsuario);
    localStorage.setItem('ecoruta_usuario', JSON.stringify(datosUsuario));
    return { exito: true, mensaje: 'Inicio de sesión exitoso' };
  }

  logout(): void {
    this.usuarioActual.set(null);
    localStorage.removeItem('ecoruta_usuario');
    this.router.navigate(['/login']);
  }

  obtenerTecnicos(): Usuario[] {
    return this.usuariosDemo
      .filter(u => u.rol === RolUsuario.TECNICO)
      .map(({ password, ...u }) => u);
  }

  obtenerCentro(centroId: number): CentroOperativo | undefined {
    return this.centros.find(c => c.id === centroId);
  }

  obtenerCentroDeOperador(tecnicoId: number): CentroOperativo | undefined {
    const tecnico = this.usuariosDemo.find(u => u.id === tecnicoId);
    if (!tecnico?.baseId) return undefined;
    return this.obtenerCentro(tecnico.baseId);
  }
}
