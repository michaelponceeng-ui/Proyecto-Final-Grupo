import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar">
      <div class="navbar-left">
        <div class="logo" routerLink="/dashboard">
          <span class="logo-icon">&#9899;</span>
          <span class="logo-text">EcoRuta</span>
        </div>

        <div class="nav-links">
          <a routerLink="/dashboard" routerLinkActive="active" class="nav-link">
            Monitoreo
          </a>
          <a routerLink="/rutas" routerLinkActive="active" class="nav-link">
            Rutas
          </a>
        </div>
      </div>

      <div class="navbar-right">
        <span class="city-badge">Guayaquil</span>
        <div class="user-info">
          <span class="user-name">{{ auth.usuario()?.nombre }}</span>
          <span class="user-role">{{ auth.usuario()?.rol }}</span>
        </div>
        <button class="btn-logout" (click)="auth.logout()">
          Cerrar Sesi&oacute;n
        </button>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      padding: 0 24px;
      height: 56px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      z-index: 1000;
      flex-shrink: 0;
    }

    .navbar-left {
      display: flex;
      align-items: center;
      gap: 32px;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      text-decoration: none;
    }

    .logo-icon {
      font-size: 22px;
      color: #fbbf24;
    }

    .logo-text {
      font-size: 20px;
      font-weight: 800;
      color: #fbbf24;
      letter-spacing: 3px;
    }

    .nav-links {
      display: flex;
      gap: 4px;
    }

    .nav-link {
      color: #94a3b8;
      text-decoration: none;
      font-size: 13px;
      font-weight: 600;
      padding: 8px 16px;
      border-radius: 6px;
      transition: all 0.2s;
      letter-spacing: 0.3px;
    }

    .nav-link:hover {
      color: #e2e8f0;
      background: rgba(148, 163, 184, 0.1);
    }

    .nav-link.active {
      color: #fbbf24;
      background: rgba(251, 191, 36, 0.1);
    }

    .navbar-right {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .city-badge {
      background: rgba(59, 130, 246, 0.15);
      color: #60a5fa;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      border: 1px solid rgba(59, 130, 246, 0.3);
    }

    .user-info {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }

    .user-name {
      color: #e2e8f0;
      font-size: 12px;
      font-weight: 600;
    }

    .user-role {
      color: #64748b;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .btn-logout {
      background: rgba(239, 68, 68, 0.15);
      color: #f87171;
      border: 1px solid rgba(239, 68, 68, 0.3);
      padding: 6px 14px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 11px;
      font-weight: 600;
      transition: all 0.2s;
    }

    .btn-logout:hover {
      background: rgba(239, 68, 68, 0.3);
    }
  `]
})
export class NavbarComponent {
  constructor(public auth: AuthService) {}
}
